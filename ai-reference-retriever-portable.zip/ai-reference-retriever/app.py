"""AI Reference Retriever - Production Processor (Midterm, Oct-20 milestone).
Standalone panel that mirrors the Photoshop-panel mockup. stdlib + requests + pillow + reportlab.
Run:  python app.py
"""
import os, json, copy, threading, queue, urllib.request, datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from validator import validate, clean_query, keywords, photo_gate, parse_years

_IM = {}
_AD = {}

def _need_imaging():
    """Import PIL on first use (keeps cold startup to stdlib+tkinter)."""
    if "Image" not in _IM:
        from PIL import Image, ImageTk
        _IM["Image"], _IM["ImageTk"] = Image, ImageTk
    return _IM["Image"], _IM["ImageTk"]

def _adapters():
    """Import all source adapters on first search (pulls in requests)."""
    if "ADAPTERS" not in _AD:
        from adapters import ADAPTERS
        _AD["ADAPTERS"] = ADAPTERS
    return _AD["ADAPTERS"]
import store

BASE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(BASE, "cache")
BOARD = os.path.join(BASE, "board")
os.makedirs(CACHE, exist_ok=True)
os.makedirs(BOARD, exist_ok=True)

VERSION = "2026-10-15o"

def logline(msg):
    try:
        with open(os.path.join(BOARD, "search_log.txt"), "a", encoding="utf-8") as f:
            f.write(datetime.datetime.now().strftime("%H:%M:%S") + " " + msg + "\n")
    except Exception:
        pass

_singleton_sock = None

def _ensure_single_instance(port=47911):
    """One retriever at a time: extra launches focus the open window and quit."""
    import socket
    import sys
    global _singleton_sock
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", port))
        s.listen(1)
    except OSError:
        _focus_existing()
        sys.exit(0)
    _singleton_sock = s  # held open for the app's lifetime
    return s

def _focus_existing():
    try:
        import ctypes
        from ctypes import wintypes
        found = []

        @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        def _cb(hwnd, _lp):
            length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
            if length:
                buf = ctypes.create_unicode_buffer(length + 1)
                ctypes.windll.user32.GetWindowTextW(hwnd, buf, length + 1)
                if buf.value.startswith("PRODUCTION PROCESSOR"):
                    found.append(hwnd)
            return True

        ctypes.windll.user32.EnumWindows(_cb, 0)
        for hwnd in found:
            ctypes.windll.user32.ShowWindow(hwnd, 9)  # SW_RESTORE
            ctypes.windll.user32.SetForegroundWindow(hwnd)
    except Exception:
        pass

def _download(url, dest, retries=2, limit=15_000_000):
    """Fetch a URL to disk with one retry; raises on failure."""
    last = None
    for _ in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=25) as r, open(dest, "wb") as f:
                f.write(r.read(limit))
            if os.path.getsize(dest) >= 500:
                return dest
            last = Exception("tiny/empty file")
        except Exception as e:
            last = e
    raise last

TIME_CHOICES = ["13th century", "14th century", "15th century", "16th century",
                "17th century", "18th century", "19th century", "20th century",
                "21st century"]

def hide_mismatches(items):
    """Split validated items into (shown, hidden_count). Mismatches never display."""
    shown = [it for it in items if it.get("validation", {}).get("verdict") != "MISMATCH"]
    return shown, len(items) - len(shown)

def split_results(shown, cap=100):
    """Split ranked, on-topic items into (grid, overflow). The grid shows the
    top `cap` (100 per prompt); overflow holds validated extras so a dismissed
    card's slot can be refilled without re-querying."""
    return shown[:cap], shown[cap:]

def rank_key(it, brief=None):
    """Sort key: verdict band first, then fit-quality signals within the band.
    Validator-passing-but-weak items (place-unverified, fallback-query,
    title-backfilled dates) sort below genuinely-fitting ones, so dismissal
    and refill deal with the weakest last. Stable beyond these signals."""
    v = it.get("validation", {})
    band = {"FITS": 0, "PRE": 1, "POST": 1, "UNKNOWN": 2}.get(v.get("verdict"), 9)
    reason = v.get("reason", "")
    extra = str(it.get("extra") or "")
    if "place match" in reason:
        place = 0
    elif "place unverified" in reason:
        place = 1
    else:
        place = 2  # no location in brief, or dateless UNKNOWN — ties stay stable
    variant = 1 if "via variant" in extra else 0
    backfill = 1 if "date from title/text" in reason else 0
    return (band, place, variant, backfill)

DISMISSED_FILE = os.path.join(BOARD, "dismissed.json")

def prompt_key(b):
    """Stable id for 'the same prompt': normalized title/time/location.
    Dismissals are remembered under this key so a repeat search skips what
    the user already rejected — without affecting different prompts."""
    return " | ".join([(b.get(k) or "").strip().lower()
                       for k in ("title", "time_period", "location")])

def load_dismissed(path=DISMISSED_FILE):
    """Return {prompt_key: set(ids)}; missing/corrupt file -> {}."""
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return {k: set(v) for k, v in d.items()
                if isinstance(k, str) and isinstance(v, list)}
    except (OSError, ValueError):
        return {}

def save_dismissed(store, path=DISMISSED_FILE):
    """Persist {prompt_key: set(ids)}; failures are silent (never block UI)."""
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({k: sorted(v) for k, v in store.items() if v}, f, indent=1)
    except OSError:
        pass

_SEARCH_CACHE = {}          # (source, query, limit, brief_json) -> item list
_CACHE_LOCK = threading.Lock()

def _cache_key(name, vq, lim, b):
    """Session-cache key: identical source+query+budget+brief reuses adapter
    output, so repeat searches (same prompt, post-dismissal) skip the network."""
    try:
        bkey = json.dumps(b, sort_keys=True)
    except TypeError:
        bkey = repr(sorted((b or {}).items()))
    return (name, vq, lim, bkey)

def _cache_get(key):
    with _CACHE_LOCK:
        hit = _SEARCH_CACHE.get(key)
    return copy.deepcopy(hit) if hit is not None else None

def _cache_put(key, items):
    with _CACHE_LOCK:
        _SEARCH_CACHE[key] = copy.deepcopy(items)
        while len(_SEARCH_CACHE) > 300:  # session-sized, never grows unbounded
            _SEARCH_CACHE.pop(next(iter(_SEARCH_CACHE)))

def merge_plans(plan, got, primary):
    """Pure per-source merge. plan=[(query, limit)...] with plan[0] the primary;
    got={query: (items, err)}. Primary-first, deduped by id, capped at 2x the
    primary budget; fallback hits labeled `via variant`. Errors surface only
    when nothing was retrieved (joined) or every query failed (last one)."""
    seen, merged, errs = set(), [], []
    for vq, _lim in plan:
        items, err = got.get(vq, ([], None))
        if err:
            errs.append(err)
        for it in items:
            if it.get("id") not in seen:
                seen.add(it.get("id"))
                if vq != primary and "via variant" not in str(it.get("extra", "")):
                    it["extra"] = (str(it.get("extra", "")) + f" | via variant '{vq}'").strip(" |")
                merged.append(it)
    budget = plan[0][1]
    merged = merged[:budget * 2]
    if not merged:
        err = "; ".join(errs) if errs else None
    elif len(errs) < len(plan):
        err = None
    else:
        err = errs[-1]
    return merged, err

def _dupe_key(it):
    """Strict cross-source duplicate key, or None when the record is too thin
    to judge (dateless, anonymous, untitled/generic). Same work catalogued by
    two sources shares creator + focused date + substantial title."""
    creator = (it.get("creator") or "").strip().lower()
    if not creator:
        return None
    title = " ".join((it.get("title") or "").lower().split())
    if len(title) < 10 or title.startswith(("untitled", "unknown")):
        return None
    years = parse_years(it.get("date_str") or "")
    if not years or len(years) > 12:
        return None
    return (creator, min(years), max(years), title)

def dedupe_items(items):
    """Drop lower-ranked cross-source duplicates from a ranked list; the first
    (best-ranked) copy wins. Returns (deduped, dupe_count)."""
    seen, out, dupes = set(), [], 0
    for it in items:
        key = _dupe_key(it)
        if key is None or key not in seen:
            if key is not None:
                seen.add(key)
            out.append(it)
        else:
            dupes += 1
    return out, dupes

def build_search_query(b):
    """Query = keywords of the prompt (title + location only, capped).
    Style/mood words ('luxury', 'art deco') poison literal archive search —
    verified: adding them zeroed OpenVerse for a portrait brief — so they stay
    out of the query and remain validator/display context."""
    kws = keywords((b.get("title", "") + " " + b.get("location", "")), cap=6)
    return " ".join(kws) or clean_query(b.get("title", ""))

def build_search_queries(b):
    """Wider retrieval that still matches the prompt: primary query plus
    prompt-faithful variants. Every variant is derived ONLY from the user's
    own Title/Location words (plus validator synonyms like bar->saloon) —
    no style/mood words, no invented terms — so the validator's topicality
    gate still holds. Adapters merge + dedupe across these; mismatches stay
    hidden by hide_mismatches()."""
    from validator import SYNONYMS
    primary = build_search_query(b)
    if not primary:
        return [clean_query(b.get("title", ""))]
    words = primary.split(" ")
    loc_toks = {w.lower() for w in
                __import__("re").findall(r"[a-z']{3,}", (b.get("location") or "").lower())}
    queries = [primary]
    # Variant 1: topic-only (drop location tokens) — catches records whose
    # metadata names the subject but not the place; place is still enforced
    # at display time via the validator's place-match note, not the query.
    nolo = " ".join(w for w in words if w.lower() not in loc_toks).strip()
    if nolo and nolo != primary and nolo not in queries:
        queries.append(nolo)
    # Variant 2: period-synonym swap on the first swappable word
    # (e.g. 19th-c. US cataloging calls bars "saloons" — verified LOC gap).
    for i, w in enumerate(words):
        syns = list(SYNONYMS.get(w.lower(), ()))
        if syns:
            swapped = " ".join(words[:i] + [syns[0]] + words[i + 1:])
            if swapped not in queries:
                queries.append(swapped)
            break
    # Variant 3: shortened core (2 longest words) — archives AND every token,
    # so a short core recalls partial-metadata records the full query misses.
    core = " ".join(sorted(words, key=len, reverse=True)[:2])
    if core and core not in queries and core != nolo:
        queries.append(core)
    return queries[:3]

def grid_columns(avail_width, card_min=220):
    """Responsive grid math (pure, tested): how many cards fit side by side."""
    try:
        return max(1, int(avail_width // card_min))
    except (TypeError, ValueError):
        return 3

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"PRODUCTION PROCESSOR {VERSION}  [x]")
        self.geometry("760x980")
        self.minsize(480, 640)  # flexible down to a usable floor, scrollbars below that
        logline(f"=== started {VERSION} ===")
        self.brief = {"title": "", "time_period": "", "location": "",
                      "styles": [], "media": ["Photograph", "Painting", "Illustration"],
                      "exclude": []}
        self.results = []          # list of item dicts with validation
        self._overflow = []        # validated extras beyond the grid cap (dismiss refills)
        self.dismissed = set()     # ids rejected for THIS prompt (session + persisted)
        self.dismissed_store = load_dismissed()  # {prompt_key: set(ids)} across sessions
        self.prompt_key = ""       # prompt_key of the current search
        self.approved, self.toreview = [], []
        self.img_queue = queue.Queue()
        self._img_sem = threading.Semaphore(12)  # max concurrent thumb downloads
        self.prog_queue = queue.Queue()
        self.photos = {}           # id -> PhotoImage (keep refs)
        self.prefetch_gen = 0      # bumped per search; stale prefetchers quit
        # vertical sash layout: brief / results / collections share height with
        # draggable dividers; results absorbs window growth, footer stays fixed
        self.panes = ttk.Panedwindow(self, orient="vertical")
        self.panes.pack(fill="both", expand=True)
        brief_f = self._build_brief(self.panes)
        results_f = self._build_results(self.panes)
        coll_f = self._build_collections(self.panes)
        self.panes.add(brief_f, weight=0)
        self.panes.add(results_f, weight=1)
        self.panes.add(coll_f, weight=0)
        try:
            self.panes.pane(brief_f, minsize=240)
            self.panes.pane(results_f, minsize=160)
            self.panes.pane(coll_f, minsize=140)
        except tk.TclError:
            pass
        self._build_footer()
        self.after(200, self._drain_images)
        self.after(100, self._poll_progress)

    # ---------- layout ----------
    def _build_brief(self, parent):
        f = ttk.LabelFrame(parent, text="PROJECT BRIEF", padding=8)
        f.columnconfigure(1, weight=1)
        f.columnconfigure(2, weight=1)
        f.columnconfigure(3, weight=1)
        ttk.Label(f, text="Title:").grid(row=0, column=0, sticky="w")
        self.e_title = ttk.Entry(f, width=52)
        self.e_title.insert(0, self.brief["title"])
        self.e_title.grid(row=0, column=1, columnspan=3, sticky="ew")
        ttk.Label(f, text="Time Period:").grid(row=1, column=0, sticky="w")
        self.e_time = ttk.Combobox(f, values=TIME_CHOICES, width=28)
        self.e_time.set(self.brief["time_period"])
        self.e_time.grid(row=1, column=1, columnspan=3, sticky="ew")
        ttk.Label(f, text="Location/Culture:").grid(row=2, column=0, sticky="w")
        self.e_loc = ttk.Entry(f, width=32)
        self.e_loc.insert(0, self.brief["location"])
        self.e_loc.grid(row=2, column=1, columnspan=3, sticky="ew")
        ttk.Label(f, text="Style/Mood:").grid(row=3, column=0, sticky="w")
        self.e_styles = ttk.Entry(f, width=52)
        self.e_styles.insert(0, ", ".join(self.brief["styles"]))
        self.e_styles.grid(row=3, column=1, columnspan=3, sticky="ew")
        ttk.Label(f, text="Medium:").grid(row=4, column=0, sticky="w")
        self.v_photo = tk.BooleanVar(value=True); self.v_paint = tk.BooleanVar(value=True); self.v_illus = tk.BooleanVar(value=True)
        ttk.Checkbutton(f, text="Photograph", variable=self.v_photo).grid(row=4, column=1, sticky="w")
        ttk.Checkbutton(f, text="Painting", variable=self.v_paint).grid(row=4, column=2, sticky="w")
        ttk.Checkbutton(f, text="Illustration", variable=self.v_illus).grid(row=4, column=3, sticky="w")
        ttk.Label(f, text="Exclude:").grid(row=5, column=0, sticky="w")
        self.e_exc = ttk.Entry(f, width=52)
        self.e_exc.insert(0, ", ".join(self.brief["exclude"]))
        self.e_exc.grid(row=5, column=1, columnspan=3, sticky="ew")
        self.b_search = ttk.Button(f, text="🔍 SEARCH ALL SOURCES", command=self.search_all)
        self.b_search.grid(row=6, column=1, columnspan=2, pady=6)
        self.lbl_status = ttk.Label(f, text="Ready. Sources: NGA, LOC, Met, Commons, Cleveland, AIC, Wellcome, OpenVerse(PD) — all dated except OV.", foreground="gray")
        self.lbl_status.grid(row=7, column=0, columnspan=4, sticky="w")
        return f

    def _build_results(self, parent):
        f = ttk.LabelFrame(parent, text="RESULTS", padding=8)
        self.lbl_count = ttk.Label(f, text="No results yet.")
        self.lbl_count.pack(anchor="w")
        prog_row = ttk.Frame(f); prog_row.pack(fill="x", pady=2)
        self.progress = ttk.Progressbar(prog_row, orient="horizontal", mode="determinate",
                                        maximum=100, value=0)
        self.progress.pack(side="left", fill="x", expand=True)
        self.lbl_prog = ttk.Label(prog_row, text="", width=32)
        self.lbl_prog.pack(side="left", padx=6)
        cv_wrap = ttk.Frame(f); cv_wrap.pack(fill="both", expand=True)
        self.canvas = tk.Canvas(cv_wrap)
        vbar = ttk.Scrollbar(cv_wrap, orient="vertical", command=self.canvas.yview)
        hbar = ttk.Scrollbar(cv_wrap, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        vbar.pack(side="right", fill="y")
        hbar.pack(side="bottom", fill="x")
        self.grid_frame = ttk.Frame(self.canvas)
        self._canvas_win = self.canvas.create_window((0, 0), window=self.grid_frame, anchor="nw")
        self.grid_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self._reflow())
        self.result_cards = []   # card frames in display order (re-gridded on resize)
        self._cols = 3
        return f

    def _reflow(self):
        """Responsive results grid: stretch to the canvas, reflow card columns."""
        try:
            w = self.canvas.winfo_width()
        except tk.TclError:
            return
        try:
            self.canvas.itemconfig(self._canvas_win, width=max(w - 4, 100))
        except tk.TclError:
            pass
        cols = grid_columns(w)
        if cols == self._cols:
            return
        self._cols = cols
        for c in range(cols):
            try:
                self.grid_frame.columnconfigure(c, weight=1)
            except tk.TclError:
                pass
        for i, card in enumerate(self.result_cards):
            try:
                card.grid(row=i // cols, column=i % cols, padx=6, pady=6, sticky="nsew")
            except tk.TclError:
                pass

    def _build_collections(self, parent):
        # Collections panel is intentionally a stub (approvals feed PDF/PSD
        # export directly); the pane below only holds layout space.
        return ttk.LabelFrame(parent, text="COLLECTIONS", padding=8)

    def _build_footer(self):
        f = ttk.Frame(self); f.pack(fill="x", padx=8, pady=6)
        for c in range(4):
            f.columnconfigure(c, weight=1)
        ttk.Button(f, text="💾 Load", command=self.do_load).grid(row=0, column=0, padx=4, sticky="ew")
        ttk.Button(f, text="💾 Save", command=self.do_save).grid(row=0, column=1, padx=4, sticky="ew")
        ttk.Button(f, text="📊 PDF", command=self.do_pdf).grid(row=0, column=2, padx=4, sticky="ew")
        ttk.Button(f, text="🎨 PSD", command=self.do_psd).grid(row=0, column=3, padx=4, sticky="ew")

    # ---------- brief ----------
    def read_brief(self):
        media = []
        if self.v_photo.get(): media.append("Photograph")
        if self.v_paint.get(): media.append("Painting")
        if self.v_illus.get(): media.append("Illustration")
        return {"title": self.e_title.get().strip(),
                "time_period": self.e_time.get().strip(),
                "location": self.e_loc.get().strip(),
                "styles": [s.strip() for s in self.e_styles.get().split(",") if s.strip()],
                "media": media,
                "exclude": [s.strip() for s in self.e_exc.get().split(",") if s.strip()]}

    def build_query(self, b):
        return build_search_query(b)

    # ---------- search ----------
    def search_all(self):
        b = self.read_brief()
        self.brief = b
        q = self.build_query(b)
        if not q.strip():
            self.lbl_status.config(text="Type a Title (and optionally Time/Location) first, then Search.")
            return
        self.lbl_status.config(text=f"Searching {build_search_queries(b)} across {len(_adapters())} sources…")
        self.b_search.config(state="disabled")
        for w in self.grid_frame.winfo_children():
            w.destroy()
        self.results = []
        self._overflow = []
        # drop stale thumbnail refs (100-image grids add up across searches);
        # enlarged (_big) refs are kept so open lightboxes survive a research
        self.photos = {k: v for k, v in self.photos.items() if k.endswith("_big")}
        self.prefetch_gen += 1  # cancel any previous search's full-file prefetcher
        # seed this prompt's rejection memory: ids dismissed in an earlier
        # session under the same prompt never enter the grid again
        self.prompt_key = prompt_key(b)
        self.dismissed = set(self.dismissed_store.get(self.prompt_key, set()))
        if self.dismissed:
            logline(f"BLOCKED {len(self.dismissed)} previously-dismissed for this prompt")
        self.lbl_count.config(text="Searching…")
        self.progress.config(value=0)
        self.lbl_prog.config(text="Searching 0%")
        th = threading.Thread(target=self._search_worker, args=(q, b), daemon=True)
        th.start()

    def _search_worker(self, q, b):
        logline(f"SEARCH brief={json.dumps(b)[:200]} query={q!r}")
        queries = build_search_queries(b)
        logline(f"QUERIES {queries}")
        # wide-but-faithful: bigger per-source budgets, primary + variants
        # merged per source, validator hides anything off-prompt.
        AD = _adapters()
        names = list(AD)
        # 100-image grid: budgets sized so ~100 survive validation/hiding
        # (roughly half of raw fetches hide as mismatches on typical briefs).
        per_source = {"LOC": 20, "NGA": 18, "Met": 18, "Commons": 18,
                      "Cleveland": 14, "AIC": 18, "Wellcome": 18, "OpenVerse": 18}
        # primary gets the full budget; each variant gets half (still capped by
        # the adapter) so recall widens without one variant drowning the
        # source's native relevance order.
        plans = {n: [(queries[0], per_source.get(n, 4))] +
                    [(v, max(2, per_source.get(n, 4) // 2)) for v in queries[1:]]
                 for n in names}
        tasks = [(n, vq, lim) for n in names for (vq, lim) in plans[n]]
        total = len(tasks)
        errors, done = [], [0]
        bkey = _cache_key("", "", 0, b)[3]  # brief signature shared by all tasks

        def fetch_one(task):
            name, vq, lim = task
            key = (name, vq, lim, bkey)
            hit = _cache_get(key)
            if hit is not None:
                return name, vq, hit, None
            try:
                items, err = AD[name](vq, lim, brief=b)
            except Exception as e:
                return name, vq, [], f"{name} [{vq}]: {e}"
            if err:
                return name, vq, items, f"{name} [{vq}]: {err}"
            _cache_put(key, items)  # clean hits only; errors stay live
            return name, vq, items, None

        # one pool over (source, query) pairs: a source's queries run together
        # instead of sequentially, so search time is the slowest single query,
        # not the sum per source. Repeat prompts hit the session cache.
        got = {}
        with ThreadPoolExecutor(max_workers=20) as pool:
            futs = {pool.submit(fetch_one, t): t for t in tasks}
            for fut in as_completed(futs):
                name, vq, items, err = fut.result()
                got.setdefault(name, {})[vq] = (items, err)
                done[0] += 1
                pct = int(done[0] / total * 100)
                self.prog_queue.put((pct, f"Searching {pct}% — {done[0]}/{total} queries ({name} done)"))
        results = {}
        for name in names:
            items, err = merge_plans(plans[name], got.get(name, {}), queries[0])
            results[name] = (items, err)
        all_items = []
        for name in names:  # source order kept: native relevance order within bands
            items, err = results[name]
            for it in items:
                it["_src"] = name
                it["validation"] = validate(it, b)
            all_items.extend(items)
            if err:
                errors.append(err)
        # rejection memory: ids dismissed under this prompt never return —
        # filtered before ranking so their slots go to fresh results
        n_blocked = 0
        if self.dismissed:
            kept = [it for it in all_items if it.get("id") not in self.dismissed]
            n_blocked = len(all_items) - len(kept)
            all_items = kept
        # rank: Fits first, then Unknown/Pre/Post, fit-quality within bands.
        # Mismatches are hidden, not shown.
        shown, hidden = hide_mismatches(all_items)
        excl = sum(1 for it in all_items
                   if it["validation"]["verdict"] == "MISMATCH"
                   and it["validation"]["reason"].startswith("excluded:"))
        off = sum(1 for it in all_items
                  if it["validation"]["verdict"] == "MISMATCH"
                  and it["validation"]["reason"].startswith("off-topic"))
        shown.sort(key=lambda it: rank_key(it, b))
        # cross-source duplicates (same work in two archives) waste grid slots
        shown, n_dupes = dedupe_items(shown)
        self.results, self._overflow = split_results(shown)
        from collections import Counter
        logline(f"DONE shown={len(self.results)} over={len(self._overflow)} "
                f"blocked={n_blocked} dupes={n_dupes} hidden={hidden} "
                f"verdicts={dict(Counter(i['validation']['verdict'] for i in all_items))} "
                f"errors={'; '.join(errors)[:300]}")
        for it in self.results:
            logline(f"  SHOW {it['validation']['label']} | {it.get('_src')} | "
                    f"{str(it.get('date_str'))[:14]} | {str(it.get('title'))[:60]}")
        try:
            self.after(0, lambda: self._render_results(errors, hidden, excl, off))
        except Exception as e:
            logline(f"RENDER-FAIL {e}")

    def _poll_progress(self):
        try:
            while True:
                pct, msg = self.prog_queue.get_nowait()
                try:
                    self.progress.config(value=pct)
                    self.lbl_prog.config(text=msg)
                except tk.TclError:
                    pass
        except queue.Empty:
            pass
        self.after(100, self._poll_progress)

    def _update_count(self):
        hid = f" ({self.n_hidden} mismatch{'es' if self.n_hidden != 1 else ''} hidden)" if self.n_hidden else ""
        try:
            self.lbl_count.config(text=f"Showing {self.n_shown} results from {', '.join(self.count_srcs)}{hid}")
        except tk.TclError:
            pass

    def _hide_card(self, item_id, reason):
        """Drop a card from the grid (no preview / failed color-era gate)."""
        entry = self.card_of.pop(item_id, None)
        if not entry:
            return
        card, vlbl = entry
        kept = [d for d in (self.approved + self.toreview) if d.get("id") == item_id]
        for it in self.results:
            if it.get("id") == item_id:
                it["validation"] = {"verdict": "MISMATCH", "label": "✕ Mismatch",
                                    "reason": reason}
                break
        try:
            if kept:
                vlbl.config(text=f"✕ {reason} (kept: you approved it)")
            else:
                card.grid_remove()
                self.result_cards = [c for c in self.result_cards if c is not card]
                self.results = [r for r in self.results if r.get("id") != item_id]
                self.n_hidden += 1
                self._refill()  # fill the hole left by the auto-hidden card
                self.n_shown = len(self.results)
                self._update_count()
                if self.n_shown == 0 and not self._overflow:
                    self._empty_box([], from_hide=True)
        except tk.TclError:
            pass

    def _apply_gate(self, item_id):
        """A preview arrived in full color under a pre-color-era brief: hide its card."""
        self._hide_card(item_id, "color photo under a pre-1935 brief — likely modern")

    def _empty_box(self, errors, excl=0, hidden=0, from_hide=False, off=0):
        tips = []
        if excl:
            tips.append(f"{excl} hit(s) were removed by your Exclude list — clear it if you want them back")
        if off:
            tips.append(f"{off} didn't match your prompt words — check Title/Location")
        if hidden - excl - off > 0:
            tips.append(f"{hidden - excl - off} dated outside '{self.brief.get('time_period', '')}' — widen the Time Period")
        if from_hide:
            tips.append("every preview failed to download — check network, then Search again")
        tips.append("broaden the Title to fewer keywords")
        if errors:
            tips.append("some sources errored (see status bar) — retry on your home network")
        box = ttk.Frame(self.grid_frame, relief="groove", borderwidth=1, padding=12)
        box.grid(row=0, column=0, padx=6, pady=6, sticky="nsew")
        ttk.Label(box, text="No results to show.", font=("TkDefaultFont", 10, "bold")).pack(anchor="w")
        for t in tips:
            ttk.Label(box, text="• " + t, wraplength=560).pack(anchor="w")
        if not from_hide:
            msg = " | ".join(errors) if errors else "All sources answered."
            self.lbl_status.config(text=msg[:220])

    def _render_results(self, errors, hidden=0, excl=0, off=0):
        self.b_search.config(state="normal")
        self.progress.config(value=100)
        self.lbl_prog.config(text="Done 100% — loading previews…")
        srcs = sorted(set(it["_src"] for it in self.results)) or ["—"]
        self.count_srcs = srcs
        self.n_shown, self.n_hidden = len(self.results), hidden
        self.card_of = {}
        self.gate_brief = dict(self.brief)
        self.result_cards = []
        for c in range(max(self._cols, 1)):
            self.grid_frame.columnconfigure(c, weight=1)
        self._update_count()
        if not self.results:
            self._empty_box(errors, excl, hidden, off=off)
            return
        for i, it in enumerate(self.results):
            self.result_cards.append(self._build_card(it, i))
        self._prefetch_fulls(list(self.results))
        msg = " | ".join(errors) if errors else "All sources OK."
        self.lbl_status.config(text=msg[:220])

    def _build_card(self, it, index):
        """Create one result card widget (gridded at `index`), fetch its thumb."""
        card = ttk.Frame(self.grid_frame, relief="groove", borderwidth=1, padding=6)
        card.grid(row=index // self._cols, column=index % self._cols, padx=6, pady=6, sticky="nsew")
        ttk.Label(card, text=f"[{it['_src']}]", foreground="gray", font=("TkDefaultFont", 8)).pack()
        img_lbl = ttk.Label(card, text="[image loading…]", cursor="hand2")
        img_lbl.pack()
        img_lbl.bind("<Button-1>", lambda _e, it=it: self.enlarge(it))
        ttk.Label(card, text=(it.get("title") or "")[:40], wraplength=170, font=("TkDefaultFont", 8, "bold")).pack()
        ttk.Label(card, text=f"{it.get('source','')} {it.get('date_str','')}"[:44], font=("TkDefaultFont", 8)).pack()
        vlbl = ttk.Label(card, text=f"{it['validation']['label']} — {it['validation']['reason']}"[:60],
                         wraplength=170, font=("TkDefaultFont", 8))
        vlbl.pack()
        self.card_of[it.get("id")] = (card, vlbl)
        btns = ttk.Frame(card); btns.pack(pady=2)
        ttk.Button(btns, text="↓drag", width=6, command=lambda it=it: self.download(it)).pack(side="left", padx=2)
        ttk.Button(btns, text="✓", width=3, command=lambda it=it: self.collect(it, True)).pack(side="left", padx=2)
        ttk.Button(btns, text="✕", width=3, command=lambda it=it: self.dismiss(it)).pack(side="left", padx=2)
        self._fetch_thumb(it, img_lbl, self.gate_brief)
        return card

    def _regrid(self):
        """Re-grid cards in order after a removal (fills the hole, keeps order)."""
        for i, card in enumerate(self.result_cards):
            try:
                card.grid(row=i // self._cols, column=i % self._cols, padx=6, pady=6, sticky="nsew")
            except tk.TclError:
                pass

    def _refill(self):
        """Pull the next validated extra from the overflow buffer into the grid."""
        while self._overflow:
            nxt = self._overflow.pop(0)
            if nxt.get("id") in self.dismissed:
                continue
            if any(r.get("id") == nxt.get("id") for r in self.results):
                continue
            self.results.append(nxt)
            logline(f"  REFILL {nxt['validation']['label']} | {nxt.get('_src')} | "
                    f"{str(nxt.get('date_str'))[:14]} | {str(nxt.get('title'))[:60]}")
            self.result_cards.append(self._build_card(nxt, len(self.result_cards)))
            self.count_srcs = sorted(set(it["_src"] for it in self.results)) or ["—"]
            self._prefetch_fulls([nxt])
            return True
        self._regrid()
        return False

    def dismiss(self, it):
        """✕: drop the card from the grid and refill its slot with the next
        validated result (never a dismissed or already-shown id). The rejection
        is remembered under this prompt, so a repeat search skips it too."""
        item_id = it.get("id")
        self.dismissed.add(item_id)
        self.dismissed_store.setdefault(self.prompt_key, set()).add(item_id)
        save_dismissed(self.dismissed_store)
        entry = self.card_of.pop(item_id, None)
        if entry:
            card, _vlbl = entry
            try:
                card.destroy()
            except tk.TclError:
                pass
            self.result_cards = [c for c in self.result_cards if c is not card]
        self.results = [r for r in self.results if r.get("id") != item_id]
        logline(f"DISMISS {item_id}")
        self._refill()
        self.n_shown = len(self.results)
        self._update_count()
        if not self.results and not self._overflow:
            self._empty_box([], from_hide=True)

    def _prefetch_fulls(self, items):
        """Idle-download full files after a search so enlarge() is instant."""
        self.prefetch_gen += 1
        gen = self.prefetch_gen

        def worker():
            for it in items:
                if gen != self.prefetch_gen:
                    return
                # speed tier, same file enlarge() wants — originals stay on ↓drag
                url = it.get("large_url") or it.get("image_url") or ""
                if not url:
                    continue
                fn = os.path.join(CACHE, (it.get("id") or "img").replace("/", "_") + ".full")
                try:
                    if not os.path.exists(fn) or os.path.getsize(fn) < 1000:
                        _download(url, fn)
                except Exception:
                    pass
        threading.Thread(target=worker, daemon=True).start()

    # ---------- images ----------
    def _fetch_thumb(self, it, label, brief=None):
        Image, _ = _need_imaging()

        def worker():
            with self._img_sem:  # 100-card grids share 12 download slots
                self._fetch_thumb_body(it, label, brief)
        threading.Thread(target=worker, daemon=True).start()

    def _fetch_thumb_body(self, it, label, brief=None):
        Image, _ = _need_imaging()
        url = it.get("thumb_url") or it.get("image_url")
        if not url:
            self.img_queue.put(("img", it["id"], None, label))
            return
        fn = os.path.join(CACHE, (it.get("id") or "img").replace("/", "_") + ".thumb.jpg")
        try:
            if not os.path.exists(fn) or os.path.getsize(fn) < 500:
                _download(url, fn, limit=3_000_000)
            try:
                im = Image.open(fn).convert("RGB")
            except Exception:
                os.remove(fn)  # corrupt cache: re-fetch once, then give up
                _download(url, fn, limit=3_000_000)
                im = Image.open(fn).convert("RGB")
            im.thumbnail((160, 120))
            self.img_queue.put(("img", it["id"], im, label))
            if brief and photo_gate(fn, it, brief) == "modern":
                self.img_queue.put(("gate", it["id"], None, None))
        except Exception:
            self.img_queue.put(("img", it["id"], None, label))

    def _drain_images(self):
        _, ImageTk = _need_imaging()
        try:
            while True:
                msg = self.img_queue.get_nowait()
                if msg[0] == "gate":
                    self._apply_gate(msg[1])
                    continue
                _, _id, im, label = msg
                if im is None:
                    # no preview available: drop the card instead of showing a dead box
                    self._hide_card(_id, "no preview available")
                    continue
                try:
                    ph = ImageTk.PhotoImage(im)
                    self.photos[_id] = ph
                    label.config(image=ph, text="")
                except tk.TclError:
                    pass
        except queue.Empty:
            pass
        self.after(200, self._drain_images)

    # ---------- collections ----------
    def collect(self, it, ok):
        dest = self.approved if ok else self.toreview
        if all(d.get("id") != it.get("id") for d in dest):
            dest.append(it)
        self.refresh_lists()

    def refresh_lists(self):
        pass  # no-op: collections panel is a stub; approvals feed PDF/PSD export

    def enlarge(self, it):
        """Click-to-enlarge lightbox: cached thumbnail instantly, full file behind it."""
        top = tk.Toplevel(self)
        top.title((it.get("title") or "image")[:60])
        top.geometry("960x800")
        cap = (f"{it.get('title','')}\n{it.get('creator','')} | {it.get('source','')} "
               f"{it.get('date_str','')}\n{it['validation']['label']} — {it['validation']['reason']}\n"
               f"Page: {it.get('page_url','')}")
        ttk.Label(top, text=cap, wraplength=900, justify="left").pack(pady=6)
        body = ttk.Label(top, text="Loading…")
        body.pack(expand=True)
        status = ttk.Label(top, text="", foreground="gray")
        status.pack()
        btns = ttk.Frame(top)
        ttk.Button(btns, text="✓ Approve", command=lambda: (self.collect(it, True), top.destroy())).pack(side="left", padx=4)
        ttk.Button(btns, text="↓ Save full", command=lambda: self.download(it)).pack(side="left", padx=4)
        ttk.Button(btns, text="Close", command=top.destroy).pack(side="left", padx=4)
        btns.pack(pady=8)

        # instant: the already-cached thumbnail, enlarged
        Image, _ = _need_imaging()
        state = {"orig": None, "job": None}
        thumb_fn = os.path.join(CACHE, (it.get("id") or "img").replace("/", "_") + ".thumb.jpg")
        try:
            if os.path.exists(thumb_fn):
                state["orig"] = Image.open(thumb_fn).convert("RGB")
                self._show_enlarged(body, top, state["orig"].copy(), it, res=(900, 640))
                status.config(text="preview — full image loading…")
            else:
                body.config(text="Loading full image…")
        except Exception:
            body.config(text="Loading full image…")
        top.bind("<Configure>", lambda _e: self._lightbox_refit(body, top, it, state))

        full_fn = os.path.join(CACHE, (it.get("id") or "img").replace("/", "_") + ".full")

        def worker():
            url = it.get("large_url") or it.get("image_url") or it.get("thumb_url") or ""
            if not url:
                self.after(0, lambda: body.config(text="No image file for this record."))
                return
            try:
                if not os.path.exists(full_fn) or os.path.getsize(full_fn) < 1000:
                    _download(url, full_fn)
                im = Image.open(full_fn).convert("RGB")

                def _got():
                    state["orig"] = im
                    self._lightbox_refit(body, top, it, state)
                    status.config(text="")
                self.after(0, _got)
            except Exception as e:
                def _fail():
                    status.config(text="")
                    if os.path.exists(thumb_fn):
                        status.config(text="showing preview (full image failed)")
                    else:
                        body.config(text=f"Full image failed ({e}).\nOpen the page instead:\n{it.get('page_url','')}")
                self.after(0, _fail)
        threading.Thread(target=worker, daemon=True).start()

    def _show_enlarged(self, body, top, im, it, res=(900, 640)):
        _, ImageTk = _need_imaging()
        try:
            im.thumbnail(res)
            ph = ImageTk.PhotoImage(im)
            self.photos[it.get("id") + "_big"] = ph
            body.config(image=ph, text="")
        except tk.TclError:
            try:
                body.config(text="Could not display image.")
            except tk.TclError:
                pass

    def _lightbox_refit(self, body, top, it, state):
        """Re-fit the lightbox image to the current window size (debounced)."""
        if state.get("job"):
            try:
                top.after_cancel(state["job"])
            except tk.TclError:
                return
        def _do():
            state["job"] = None
            orig = state.get("orig")
            if orig is None:
                return
            try:
                w = max(top.winfo_width() - 40, 200)
                h = max(top.winfo_height() - 260, 200)
            except tk.TclError:
                return
            self._show_enlarged(body, top, orig.copy(), it, res=(w, h))
        try:
            state["job"] = top.after(250, _do)
        except tk.TclError:
            pass

    def download(self, it):
        """↓drag: save full image to board/ for Photoshop drag-in."""
        url = it.get("image_url")
        if not url:
            messagebox.showinfo("drag", "No image URL for this item.")
            return
        fn = os.path.join(BOARD, (it.get("id") or "img").replace("/", "_") + ".jpg")
        Image, _ = _need_imaging()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as r, open(fn, "wb") as f:
                f.write(r.read(15_000_000))
            # also keep a full copy in cache for PSD export
            cf = os.path.join(CACHE, (it.get("id") or "img").replace("/", "_") + ".full")
            try:
                Image.open(fn).convert("RGB").save(cf, "JPEG")
            except Exception:
                pass
            messagebox.showinfo("drag", f"Saved:\n{fn}\nDrag this file into Photoshop, or use Export PSD+JSX.")
        except Exception as e:
            messagebox.showerror("drag failed", f"{e}\n\nRate-limit/hotlink protection is common — open Page URL instead:\n{it.get('page_url')}")

    # ---------- session ----------
    def do_save(self):
        b = self.read_brief()
        p = filedialog.asksaveasfilename(defaultextension=".json", initialfile="brief.json",
                                         filetypes=[("JSON", "*.json")])
        if p:
            store.save_brief(p, b, self.approved, self.toreview)
            self.lbl_status.config(text=f"Saved brief → {p}")

    def do_load(self):
        p = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if not p:
            return
        try:
            d = store.load_brief(p)
            b = d.get("brief", d)
            self.e_title.delete(0, "end"); self.e_title.insert(0, b.get("title", ""))
            self.e_time.set(b.get("time_period", ""))
            self.e_loc.delete(0, "end"); self.e_loc.insert(0, b.get("location", ""))
            self.e_styles.delete(0, "end"); self.e_styles.insert(0, ", ".join(b.get("styles", [])))
            self.e_exc.delete(0, "end"); self.e_exc.insert(0, ", ".join(b.get("exclude", [])))
            self.approved, self.toreview = d.get("approved", []), d.get("to_review", [])
            # re-validate loaded items against this brief
            for it in self.approved + self.toreview:
                it["validation"] = validate(it, b)
            self.refresh_lists()
            self.lbl_status.config(text=f"Loaded brief ← {p}")
        except Exception as e:
            messagebox.showerror("Load failed", str(e))

    def do_pdf(self):
        items = self.approved + self.toreview or self.results
        if not items:
            messagebox.showinfo("Export", "Nothing to export — search first.")
            return
        p = filedialog.asksaveasfilename(defaultextension=".pdf", initialfile="board.pdf",
                                         filetypes=[("PDF", "*.pdf")])
        if p:
            try:
                store.export_pdf(p, self.read_brief(), items, CACHE)
                self.lbl_status.config(text=f"Exported PDF → {p}")
            except Exception as e:
                messagebox.showerror("PDF failed", str(e))

    def do_psd(self):
        items = self.approved + self.toreview or self.results
        if not items:
            messagebox.showinfo("Export", "Nothing to export — search first.")
            return
        try:
            psd, jsx = store.export_psd_and_jsx(BOARD, items, CACHE)
            self.lbl_status.config(text=f"Board → {BOARD} | attribution.txt + load_in_photoshop.jsx (File > Scripts > Browse in Photoshop)")
            messagebox.showinfo("PSD export",
                f"Saved board folder:\n{BOARD}\n\n- {os.path.basename(psd)} (flattened contact sheet)\n- load_in_photoshop.jsx (run in Photoshop: File > Scripts > Browse)\n- attribution.txt (paste into your PSD credits layer)")
        except Exception as e:
            messagebox.showerror("PSD failed", str(e))

if __name__ == "__main__":
    _ensure_single_instance()
    App().mainloop()
