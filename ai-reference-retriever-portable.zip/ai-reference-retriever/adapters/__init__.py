"""Adapters: each search(query, limit) -> (items, error). Item dict: id,title,date_str,creator,source,image_url,thumb_url,page_url,medium,extra."""
from .loc import search as search_loc
from .nga import search as search_nga
from .met import search as search_met
from .commons import search as search_commons
from .cleveland import search as search_cleveland
from .artic import search as search_artic
from .wellcome import search as search_wellcome
from .openverse import search as search_openverse

# Every source must carry verifiable dates in its metadata (OpenVerse was
# removed: no artwork dates, only index timestamps).
ADAPTERS = {
    "NGA": search_nga,
    "LOC": search_loc,
    "Met": search_met,
    "Commons": search_commons,
    "Cleveland": search_cleveland,
    "AIC": search_artic,
    "Wellcome": search_wellcome,
    "OpenVerse": search_openverse,
}
