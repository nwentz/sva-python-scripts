# AI Reference Retriever — Production Processor (Midterm, Oct-20 milestone)

Standalone Python panel matching your ASCII mockup. Photoshop-live via drag-in + JSX.

## Run
```
Unzip ai-reference-retriever-portable.zip
Windows: double-click run.bat   (installs libraries on first launch, then opens the GUI)
Mac:     double-click run.sh    (or run ./run.sh in Terminal)
```

## What maps to your timeline
- **Oct 13**: panel GUI ✓, LOC live ✓, prompt inputs w/ constraints ✓,
  Search button ✓, metadata + thumbnails inline (no browser) ✓
- Click any thumbnail to enlarge it (full image + full attribution, approve/save
  from the popup). Cards whose preview won't download are removed, not left blank.
- **Oct 20**: NGA connected ✓,
  validation icons ✓ Fits / △ Post-brief / ✕ Mismatch / ? Unknown ✓,
  Approve / To-Review moodboard ✓, Save session + Export PDF / PSD+JSX ✓
  (try `sample_brief_1890s_ireland_bar.json` via Load Brief)

## Source honesty (risky parts you flagged)
- **OpenVerse**: back as PD-only (`license=pdm,cc0`, commercial-safe) with
  keyword-must-match on title/creator/tags. No artwork dates exist there, so its
  hits stay `?` (verify date at source) — dateless, never dateless-and-random.
- **LOC**: live keyless `fo=json` ✓ (needs browser User-Agent; retries on 403/rate-limit)
- **NGA**: real local search — `python scripts/nga_build.py` (once) downloads the Gallery's
  CC0 open-data dump (146k objects, 64k open-access images) into `data/nga.sqlite`;
  queries run full-text with brief year-overlap and IIIF images. No keyless NGA
  search API exists, so the data lives on your disk instead.
- **Picryl**: removed — no public API exists (repo 404, old API host dead, site 403s bots).
- **Met**: live keyless Collection API (v1.1 search + object records), native
  dateBegin/dateEnd filtering; image URLs served for public-domain works only,
  so every Met hit is dated, hi-res, and openly reusable.
- **Commons**: live keyless MediaWiki API (site relevance order, bitmap files).
  Artwork dates come from the file's date field/filename/categories — never the
  upload timestamp; unattributable-date files stay `?` with artist + license shown.
- **Cleveland**: live keyless Open Access API (64k CC0 records), native
  created_after/created_before facet; web-size previews, print-size drag-ins
  (50MB+ .tif masters never fetched).
- **AIC**: live keyless REST API (50k+ PD/CC0 works), same-field date_start range
  facet (API takes one query clause per GET, so PD is enforced client-side);
  IIIF 400px previews, 1686px drag-ins.
- **Wellcome**: live keyless catalogue API (historical photos/drawings), production
  dates + per-record IIIF + license; only public-domain-marked records kept
  (mixed-rights catalogue), dated hits ranked first.
- Every card shows its error state; failures degrade to `? Unknown`, never a fake ✓.

## Photoshop handoff
- `↓drag` saves full JPG to `board/` — drag straight into Photoshop.
- `Export Board (PSD+JSX)` writes `board/board.psd` (flattened contact sheet),
  `board/load_in_photoshop.jsx` (File > Scripts > Browse in Photoshop),
  `board/attribution.txt` (credits for time period / location / artist).
- `Export Board (PDF)` writes a contact sheet with source + date + validation + attribution.

## Validation rule (hand-checkable, no key)
Date parsed from metadata → compared to brief range (`1920s`=1920-29, `1890s`, `1750-1780`,
`Colonial`=1607-83). Within range = ✓, ≤12y outside = △, >35y off or excluded-term hit = ✕ (hidden from
the grid — the header shows how many were suppressed), no date / fetch fail = ?.
Topicality is enforced too: a record showing none of your prompt words (or
close synonyms like bust→portrait, saloon→bar) in its title/artist/medium is
hidden as off-topic — a bare place word doesn't count unless place is the whole
prompt. Exclusions are plural-aware ("women" catches "woman"/"ladies").
Two extra guards: book/text formats (covers, title pages) are hidden unless your
brief mentions books/covers; and under a pre-1935 brief, dateless photo-like hits
are pixel-checked as previews arrive — full-color ones are hidden as likely modern
(B&W and sepia pass; paintings are exempt; dated items are judged by date).
Search terms are keywords from your Title + Location (stopwords, dates, and
placeholder locations like "Anywhere" removed, max 4). Each source leads with
your keywords plus the period facet — i.e. what its own site shows with the
date filter ticked — in native relevance order; shortened/synonym fallbacks
fire only on empty hits and are labeled (`via variant ...`) in the attribution.
Style/mood words stay out of the query, and each source shortens further on
empty hits.
