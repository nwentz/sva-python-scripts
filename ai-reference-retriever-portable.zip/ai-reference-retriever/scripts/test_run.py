"""Smoke tests for Oct-20 milestone (no GUI needed). Run: python scripts/test_run.py"""
import os, sys
_here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _here)                        # scripts/
sys.path.insert(0, os.path.dirname(_here))       # project root: validator, store, app
from validator import parse_years, brief_range, validate
import store

fails = []
def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (" | " + str(extra) if extra else ""))
    if not cond: fails.append(name)

# validator unit checks
check("parse 1920s", 1924 in parse_years("ca. 1924"), parse_years("ca. 1924")[:4])
check("parse decade", brief_range("1920s") == (1920, 1929), brief_range("1920s"))
check("parse 1890s", brief_range("1890s") == (1890, 1899))
check("century ranges", brief_range("20th century") == (1901, 2000)
      and brief_range("19th century") == (1801, 1900)
      and brief_range("Any") is None and brief_range("") is None)
check("parse colonial range", brief_range("1750-1780") == (1750, 1780))
from validator import clean_query, keywords, photo_gate
check("clean query strips dates", clean_query("1890s bar in Ireland pub Ireland") == "bar in Ireland pub", clean_query("1890s bar in Ireland pub Ireland"))
check("keywords from prompt", keywords("1890s Bar in Ireland!") == ["bar", "ireland"], keywords("1890s Bar in Ireland!"))
check("keywords drop 'anywhere'", keywords("portrait man anywhere") == ["portrait", "man"])
check("keywords cap", len(keywords("one two three four five six seven eight")) <= 6)
import app as retriever_app
def _second_launch_exits(mod):
    import socket
    s = socket.socket()
    s.bind(("127.0.0.1", 47911))
    s.listen(1)
    try:
        mod._ensure_single_instance()
    except SystemExit:
        return True
    finally:
        s.close()
    return False
check("second launch exits when port held", _second_launch_exits(retriever_app))
check("responsive columns",
      (retriever_app.grid_columns(760), retriever_app.grid_columns(400),
       retriever_app.grid_columns(1000), retriever_app.grid_columns(100))
      == (3, 1, 4, 1))
check("query = title+location keywords, styles excluded",
      retriever_app.build_search_query({"title": "man's portrait", "location": "Paris, France",
                                        "styles": ["Art Deco", "illustration", "luxury"]}) == "man's portrait paris france",
      retriever_app.build_search_query({"title": "man's portrait", "location": "Paris, France",
                                        "styles": ["Art Deco", "illustration", "luxury"]}))
check("query drops Anywhere location",
      retriever_app.build_search_query({"title": "portrait man", "location": "Anywhere",
                                        "styles": []}) == "portrait man")
_shown, _hidden = retriever_app.hide_mismatches(
    [{"validation": {"verdict": v}} for v in ["FITS", "MISMATCH", "UNKNOWN", "POST"]])
check("mismatches hidden", len(_shown) == 3 and _hidden == 1
      and all(i["validation"]["verdict"] != "MISMATCH" for i in _shown),
      "shown=%d hidden=%d" % (len(_shown), _hidden))
_grid, _over = retriever_app.split_results([{"id": i} for i in range(105)])
check("overflow buffer beyond grid cap", len(_grid) == 100 and len(_over) == 5
      and _over[0]["id"] == 100, "grid=%d over=%d" % (len(_grid), len(_over)))
_grid2, _over2 = retriever_app.split_results([{"id": 1}])
check("short list has no overflow", len(_grid2) == 1 and _over2 == [])
# merge_plans: primary-first, deduped, capped, labeled, error semantics
def _mi(i, x=""):
    return {"id": i, "extra": x}
_plan = [("q0", 4), ("q1", 2)]
_m, _e = retriever_app.merge_plans(_plan, {"q0": ([_mi("a"), _mi("b")], None),
                                            "q1": ([_mi("b"), _mi("c")], None)}, "q0")
check("merge primary-first deduped", [i["id"] for i in _m] == ["a", "b", "c"] and _e is None)
check("merge labels fallbacks", _m[2]["extra"] == "via variant 'q1'", _m[2]["extra"])
_m2, _e2 = retriever_app.merge_plans(_plan, {"q0": ([], "boom0"), "q1": ([], "boom1")}, "q0")
check("merge all-fail joins errors", _m2 == [] and _e2 == "boom0; boom1", _e2)
_m3, _e3 = retriever_app.merge_plans(_plan, {"q0": ([_mi("a")], None), "q1": ([], "boom1")}, "q0")
check("merge partial success hides errors", [i["id"] for i in _m3] == ["a"] and _e3 is None)
_m4, _e4 = retriever_app.merge_plans([("q0", 1)], {"q0": ([_mi("a"), _mi("b"), _mi("c")], None)}, "q0")
check("merge caps at 2x budget", len(_m4) == 2)
# dedupe_items: same work in two archives collapses to the best-ranked copy
_d = [{"id": "met-1", "title": "Hoffman House Bar", "creator": "A. Artist", "date_str": "1896"},
      {"id": "aic-9", "title": "Hoffman House Bar ", "creator": "a. artist", "date_str": "c. 1896"},
      {"id": "loc-2", "title": "Hoffman House Bar", "creator": "Other Person", "date_str": "1896"},
      {"id": "x-1", "title": "Untitled", "creator": "A. Artist", "date_str": "1896"},
      {"id": "x-2", "title": "Hoffman House Bar", "creator": "", "date_str": "1896"},
      {"id": "x-3", "title": "Hoffman House Bar", "creator": "A. Artist", "date_str": ""}]
_dd, _dn = retriever_app.dedupe_items(_d)
check("dupe keeps first, drops twin", [i["id"] for i in _dd] == ["met-1", "loc-2", "x-1", "x-2", "x-3"] and _dn == 1,
      ([i["id"] for i in _dd], _dn))
# session cache keys: same brief reuses, changed brief refetches
_cb = {"title": "bar", "time_period": "1890s", "location": "Ireland", "styles": [], "media": [], "exclude": []}
check("cache key stable", retriever_app._cache_key("Met", "bar", 4, _cb) == retriever_app._cache_key("Met", "bar", 4, dict(_cb)))
check("cache key varies with brief", retriever_app._cache_key("Met", "bar", 4, _cb) != retriever_app._cache_key("Met", "bar", 4, dict(_cb, time_period="1920s")))
# within-band ranking: genuinely-fitting items lead validator-weak ones
def _rk(v, r, x=""):
    return retriever_app.rank_key({"validation": {"verdict": v, "reason": r}, "extra": x})
check("place-match FITS before place-unverified FITS",
      _rk("FITS", "1894 in 1890-1899; place match") < _rk("FITS", "1894 in 1890-1899; place unverified"))
check("direct hit before via-variant fallback",
      _rk("FITS", "1894 in 1890-1899; place match") < _rk("FITS", "1894 in 1890-1899; place match", "x | via variant 'bar'"))
check("structured date before title-backfilled date",
      _rk("FITS", "1894 in 1890-1899; place match") < _rk("FITS", "1894 in 1890-1899; place match (date from title/text — confirm at source)"))
check("band order still dominates quality signals",
      _rk("UNKNOWN", "no parseable date; verify at source") > _rk("FITS", "1894 in 1890-1899; place unverified"))
# dismissal memory: same prompt -> same key; round-trips through disk
_b1 = {"title": "1890s Bar in Ireland", "time_period": "1890s", "location": "Ireland"}
_b2 = {"title": " 1890s bar in ireland ", "time_period": "1890s", "location": "ireland"}
_b3 = {"title": "paris cafe", "time_period": "1920s", "location": "Paris"}
check("same prompt, same key", retriever_app.prompt_key(_b1) == retriever_app.prompt_key(_b2))
check("different prompt, different key", retriever_app.prompt_key(_b1) != retriever_app.prompt_key(_b3))
import tempfile
_dp = os.path.join(tempfile.gettempdir(), "_test_dismissed.json")
try:
    os.remove(_dp)
except OSError:
    pass
_store = {retriever_app.prompt_key(_b1): {"loc-1", "met-2"}}
retriever_app.save_dismissed(_store, _dp)
_rt = retriever_app.load_dismissed(_dp)
check("dismissed round-trip", _rt == {retriever_app.prompt_key(_b1): {"loc-1", "met-2"}}, _rt)
check("dismissed missing file -> {}", retriever_app.load_dismissed(_dp + ".nope") == {})
os.remove(_dp)
brief = {"title": "bar", "time_period": "1920s", "location": "Paris, France",
         "styles": ["Art Deco"], "media": ["Photograph"], "exclude": ["Modern objects"]}
check("fits", validate({"title": "cafe bar", "date_str": "1926", "extra": "", "medium": ""}, brief)["verdict"] == "FITS")
check("post-brief", validate({"title": "bar", "date_str": "1930", "extra": "", "medium": ""}, brief)["label"].startswith("△"))
check("mismatch far", validate({"title": "x", "date_str": "1975 modern objects", "extra": "", "medium": ""}, brief)["verdict"] == "MISMATCH")
check("unknown no date", validate({"title": "bar", "date_str": "", "extra": "", "medium": ""}, brief)["verdict"] == "UNKNOWN")
check("structured date beats title noise",
      validate({"title": "bar collection 1792 1833 1837 1914", "date_str": "1924", "extra": "", "medium": ""}, brief)["verdict"] == "FITS")
check("multi-year list -> unknown",
      validate({"title": "bar mural", "date_str": "1600, 1984, 1794, 1922, 1987, 1798, 1671", "extra": "", "medium": ""}, brief)["verdict"] == "UNKNOWN")
check("decade display counts as focused",
      validate({"title": "Pendant", "date_str": "1900s", "extra": "", "medium": "Jewelry"},
               {"title": "x", "time_period": "1900s", "location": "", "styles": [], "media": [], "exclude": []})["verdict"] == "FITS")
check("scattered title years -> unknown",
      validate({"title": "bar collection 1792 1837 1914", "date_str": "", "extra": "", "medium": ""}, brief)["verdict"] == "UNKNOWN")
check("place note unverified",
      "place unverified" in validate({"title": "Toronto bar room", "date_str": "1894", "extra": "", "medium": ""}, brief)["reason"])
check("place note match",
      "place match" in validate({"title": "Dublin, Ireland bar room", "date_str": "1894", "extra": "", "medium": ""},
                                {"title": "x", "time_period": "1890s", "location": "Ireland", "styles": [], "media": [], "exclude": []})["reason"])
brief1900 = {"title": "1900s portrait of a man", "time_period": "1900s", "location": "",
             "styles": [], "media": [], "exclude": []}
check("book hidden unless asked",
      validate({"title": "Leaves of history", "date_str": "1890", "extra": "", "medium": "Book/Text"},
               {"title": "x", "time_period": "1890s", "location": "", "styles": [], "media": [], "exclude": []})["reason"].startswith("book/text"))
check("book allowed when asked",
      validate({"title": "Leaves of history", "date_str": "1905", "extra": "", "medium": "Book/Text"},
               {"title": "book cover portraits", "time_period": "1900s", "location": "", "styles": [], "media": [], "exclude": []})["verdict"] == "FITS")
# photo_gate on synthetic images (no network)
from PIL import Image as _I
import tempfile
_gray = os.path.join(tempfile.gettempdir(), "_gate_gray.png")
_red = os.path.join(tempfile.gettempdir(), "_gate_red.png")
_I.new("L", (200, 200), 128).convert("RGB").save(_gray)
_I.new("RGB", (60, 60), (200, 30, 20)).save(_red)
_dless = {"title": "mystery portrait", "date_str": "", "medium": "Photograph", "extra": ""}
check("gate: gray passes", photo_gate(_gray, _dless, brief1900) == "ok")
check("gate: color modern hidden", photo_gate(_red, _dless, brief1900) == "modern")
check("gate: skipped for 2000s brief",
      photo_gate(_red, _dless, {"title": "x", "time_period": "2000s", "location": "", "styles": [], "media": [], "exclude": []}) == "skip")
check("gate: paintings exempt",
      photo_gate(_red, dict(_dless, medium="Painting"), brief1900) == "skip")
check("gate: dated items exempt",
      photo_gate(_red, dict(_dless, date_str="1905"), brief1900) == "skip")
check("_download copies file:// URLs",
      retriever_app._download("file:///" + _gray.replace(os.sep, "/").lstrip("/"),
                              os.path.join(tempfile.gettempdir(), "_dl_copy.png")) is not None)
try:
    retriever_app._download("http://127.0.0.1:1/nope.jpg",
                            os.path.join(tempfile.gettempdir(), "_dl_fail.jpg"))
    check("_download raises when unreachable", False)
except Exception:
    check("_download raises when unreachable", True)
# LOC medium mapping + photo picking (mirrors real loc.gov record shapes)
from adapters.loc import _parse as _loc_parse
_fake = {"results": [
    {"id": "1", "title": "Some book", "date": "1890", "url": "u",
     "image_url": ["https://x/cover_150px.jpg#h=150&w=120"],
     "item": {"format": ["text"], "medium": ["192 p."], "repository": "R"}},
    {"id": "2", "title": "Some photo", "date": "1900", "url": "u",
     "image_url": ["https://x/a_150px.jpg#h=150&w=119",
                   "https://x/ar.jpg#h=640&w=503",
                   "https://www.loc.gov/static/images/original-format/group-of-images.svg"],
     "item": {"format": ["still image"], "medium": ["1 negative : glass"], "repository": "R"}},
    {"id": "3", "title": "Placeholder only", "date": "1901", "url": "u",
     "image_url": ["https://www.loc.gov/static/images/original-format/group-of-images.svg"],
     "item": {"format": ["still image"], "medium": [], "repository": "R"}},
    {"id": "4", "title": "The Manning times", "date": "1908", "url": "u",
     "image_url": ["https://x/m_150px.jpg#h=150&w=120"],
     "item": {"format": ["newspapers"], "medium": ["8 p."], "repository": "R"}}]}
_parsed = _loc_parse(_fake, 3)
check("loc drops books+placeholders, keeps photos",
      [p["id"] for p in _parsed] == ["loc-2"], [p["id"] for p in _parsed])
check("loc full-size r.jpg for drag-in, 150px thumb",
      _parsed and _parsed[0]["image_url"].endswith("ar.jpg#h=640&w=503")
      and _parsed[0]["thumb_url"].endswith("a_150px.jpg#h=150&w=119"),
      (_parsed[0]["image_url"], _parsed[0]["thumb_url"]) if _parsed else None)
check("loc keeps books when brief asks",
      len(_loc_parse(_fake, 4, keep_text=True)) == 3)
check("loc medium mapping", (_parsed[0]["medium"] if _parsed else None) == "Photograph")
check("loc variant labeled",
      "via variant" in _loc_parse(_fake, 3, variant="saloon interior")[0]["extra"])

# NGA: fallback samples until nga_build.py has run; real local search after
from adapters import nga as _nga
if os.path.exists(_nga.DB):
    _rows, _fts = _nga.query_db(_nga.DB, "parasol monet", 3)
    check("nga local search finds Monet parasol",
          any("parasol" in r["title"].lower() for r in _rows), [r["title"][:40] for r in _rows])
    _rows2, _ = _nga.query_db(_nga.DB, "portrait man", 4, (1900, 1909))
    check("nga year-filtered portraits", len(_rows2) > 0, len(_rows2))
else:
    _fb, _ferr = _nga.search("portrait man", 2, brief={"time_period": "1900s"})
    check("nga fallback until index built", len(_fb) == 2 and "nga_build" in _ferr, str(_ferr)[:70])

# Met mapping (offline, mirrors real record shape) + live search
from adapters.met import _to_item
_m = _to_item({"objectID": 1, "title": "X", "objectDate": "1902",
               "artistDisplayName": "A", "department": "European Paintings",
               "primaryImage": "https://images.metmuseum.org/full.jpg",
               "primaryImageSmall": "https://images.metmuseum.org/small.jpg",
               "objectURL": "https://www.metmuseum.org/art/collection/search/1",
               "classification": "Paintings", "creditLine": "Gift",
               "isPublicDomain": True, "objectBeginDate": 1902, "objectEndDate": 1902})
check("met mapping", (_m["id"], _m["date_str"], _m["medium"]) == ("met-1", "1902", "Paintings")
      and "public domain" in _m["extra"] and _m["large_url"].endswith("small.jpg"), _m["id"])

# Commons artwork-date extraction (offline) + live search
from adapters.commons import artwork_date, _strip
check("commons strips upload HTML", _strip('<span class="x">1905</span>') == "1905")
check("commons |date= field wins",
      artwork_date("File:X.jpg", "{{Artwork |artist=A |date=1475 |medium=oil}}") == "1475")
check("commons filename year",
      artwork_date("File:Portrait of a man, Kokoschka, 1923.jpg", "no template here") == "1923")
check("commons skips photo/upload categories",
      artwork_date("File:X.jpg", "[[Category:Photographs taken on 2024-01-29]][[Category:1475 paintings]]") == "1475")
check("commons upload DateTime never leaks",
      artwork_date("File:X.jpg", "{{Art Photo |photo date = 2024-01-29}}") == "")

# Cleveland mapping (offline, mirrors the live record shape above) + live search
from adapters.cleveland import _to_item
_c = _to_item({"id": 1, "title": "Bust of a Man", "creation_date": "1905",
               "artists": [{"name": "A. Sculptor"}], "department": "European Painting and Sculpture",
               "type": "Sculpture", "technique": "Bronze", "creditline": "Gift",
               "url": "https://clevelandart.org/art/1",
               "images": {"web": {"url": "https://cdn/1_web.jpg"}, "print": {"url": "https://cdn/1_print.jpg"}}})
check("cleveland tiers", (_c["id"], _c["date_str"], _c["thumb_url"].endswith("web.jpg"),
                          _c["image_url"].endswith("print.jpg"), _c["large_url"].endswith("web.jpg"),
                          "CC0" in _c["extra"]) == ("cma-1", "1905", True, True, True, True))

# AIC mapping + PD gate (offline, mirrors live record shape)
from adapters.artic import _to_item as _aic_item, _keep as _aic_keep
_a = {"id": 1, "title": "Portrait Study", "date_display": "1901", "artist_display": "Zorn",
      "department_title": "European Painting", "medium_display": "Oil on canvas",
      "credit_line": "Gift", "image_id": "abc123", "is_public_domain": True}
_ai = _aic_item(_a)
check("aic mapping", (_ai["id"], _ai["date_str"], _ai["large_url"].endswith("843,/0/default.jpg")) == ("aic-1", "1901", True))
check("aic drops non-PD/imageless",
      (_aic_keep(_a) and not _aic_keep(dict(_a, is_public_domain=False))
       and not _aic_keep(dict(_a, image_id=None))))

# Wellcome unit (offline record shapes) — live check runs in the loop below
from adapters.wellcome import _to_item as _wl_item, _date as _wl_date, _medium as _wl_med
_wr = {"id": "abc", "title": "Siberia studio portrait", "physicalDescription": "1 photograph",
       "production": [{"label": "1914-1915", "dates": [{"label": "1914-1915"}]}],
       "contributors": [{"agent": {"label": "M. Czaplicka"}}],
       "thumbnail": {"url": "https://iiif.wellcomecollection.org/image/X/full/300,/0/default.jpg",
                     "license": {"id": "pdm", "label": "Public Domain"}}}
_wi = _wl_item(_wr)
check("wellcome mapping", (_wi["id"], _wi["date_str"], _wi["page_url"].endswith("/works/abc"),
                           _wi["large_url"].endswith("full/800,/0/default.jpg")) == ("wl-abc", "1914-1915", True, True))
check("wellcome mediums",
      (_wl_med({"physicalDescription": "1 book : ill.", "title": "Anatomy"}) == "Book/Text"
       and _wl_med({"physicalDescription": "1 drawing : pencil", "title": "Bearded man"}) == "Drawing"
       and _wl_date({"production": []}) == ""))

# OpenVerse PD-only params (offline) + topical gate units
from adapters.openverse import _params as _ov_params, _on_topic as _ov_topic
check("openverse PD commercial params",
      _ov_params("portrait man", 4).get("license") == "pdm,cc0", _ov_params("portrait man", 4))
check("openverse drops off-topic records",
      (not _ov_topic({"title": "Santosh", "creator": "x", "tags": []}, ["portrait", "man"])
       and _ov_topic({"title": "Studio portrait man", "creator": "", "tags": [{"name": "vintage"}]},
                     ["portrait", "man"])))
from validator import topical as _top
_man = {"title": "portrait man", "time_period": "1900s", "location": "", "styles": [], "media": [], "exclude": []}
check("topical: bust of a man kept",
      _top({"title": "John La Farge", "creator": "E. Burroughs", "medium": "Bust"}, _man))
check("topical: plural men kept",
      _top({"title": "Two Men, 1905", "creator": "", "medium": "Photograph"}, _man))
check("topical: cookbook hidden",
      not _top({"title": "Kalsong underwear catalog", "creator": "", "medium": ""}, _man))
check("topical: French book hidden for bar brief",
      not _top({"title": "The French invasion of Ireland", "creator": "", "medium": "Book/Text"},
               {"title": "bar", "time_period": "1890s", "location": "Ireland", "styles": ["pub"], "media": [], "exclude": []}))
check("topical: place-only cathedral hidden",
      not _top({"title": "St. Fin Barre's Cathedral, Cork", "creator": "", "medium": "Photograph"},
               {"title": "1890s bar in Ireland", "time_period": "1890s", "location": "Ireland", "styles": ["pub"], "media": [], "exclude": []}))
check("topical: place-only ok when place is the prompt",
      _top({"title": "Dublin street", "creator": "", "medium": "Photograph"},
           {"title": "Ireland", "time_period": "1890s", "location": "Ireland", "styles": [], "media": [], "exclude": []}))
check("topical: cabaret counts as bar",
      _top({"title": "At the Moulin Rouge, cabaret", "creator": "", "medium": "Painting"},
           {"title": "bar", "time_period": "1890s", "location": "", "styles": [], "media": [], "exclude": []}))

# store round-trip
os.makedirs("board", exist_ok=True)
p = "board/_test_brief.json"
store.save_brief(p, brief, [{"id": "a", "title": "t"}], [])
d = store.load_brief(p)
check("save/load", d["brief"]["time_period"] == "1920s" and len(d["approved"]) == 1, d)

# adapters import + live spot-check (network may be blocked; only fail on import errors)
try:
    from adapters import ADAPTERS
    check("8 adapters, no keyed sources", set(ADAPTERS) == {"NGA", "LOC", "Met", "Commons", "Cleveland", "AIC", "Wellcome", "OpenVerse"}, list(ADAPTERS))
    for name, fn in ADAPTERS.items():
        try:
            items, err = fn("paris cafe 1920s", 2)
            print(f"  live {name}: {len(items)} items err={str(err)[:90]}")
        except Exception as e:
            print(f"  live {name}: EXC {e}")
except Exception as e:
    check("adapters import", False, e)

print("\n%d failures" % len(fails))
sys.exit(1 if fails else 0)
