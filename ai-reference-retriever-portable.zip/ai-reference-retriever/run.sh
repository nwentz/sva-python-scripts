#!/bin/bash
# AI Reference Retriever - Mac launcher
# Double-click or run: ./run.sh
cd "$(dirname "$0")"

# Warm starts skip straight to the GUI. Delete .deps_ok to force a re-check.
if [ ! -f .deps_ok ]; then
  echo "Checking libraries..."
  python3 -c "import requests, PIL.Image, reportlab" 2>/dev/null
  if [ $? -ne 0 ]; then
    echo "Installing libraries - first run only..."
    python3 -m pip install requests pillow reportlab
  fi
  python3 -c "import requests, PIL.Image, reportlab" 2>/dev/null
  if [ $? -ne 0 ]; then
    echo ""
    echo "[!] Could not install libraries. Install Python 3.11+ from"
    echo "    https://www.python.org/downloads/ (or: brew install python@3.11)"
    echo "    then double-click run.sh again."
    read -p "Press Enter to exit..."
    exit 1
  fi
  echo ok > .deps_ok
fi

# Start the GUI
python3 app.py
