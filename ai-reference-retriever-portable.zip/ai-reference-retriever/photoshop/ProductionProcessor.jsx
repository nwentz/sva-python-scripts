// ProductionProcessor.jsx — opens the AI Reference Retriever from inside Photoshop.
// Run via File > Scripts > Browse (or copy to Presets\Scripts and restart PS).
(function () {
    var home = Folder("~");
    var cfg = File(home.fsName + "/production_processor_dir.txt");

    function valid(p) {
        return p && Folder(p).exists && File(p + "/run.bat").exists;
    }
    function loadSaved() {
        if (!cfg.exists) { return null; }
        if (!cfg.open("r")) { return null; }
        var p = cfg.read();
        cfg.close();
        return valid(p) ? p : null;
    }
    function saveDir(p) {
        if (cfg.open("w")) { cfg.write(p); cfg.close(); }
    }

    var dir = loadSaved();
    if (!dir) {
        // best guess: ai-reference-retriever in the user profile
        var guess = home.fsName + "/ai-reference-retriever";
        if (valid(guess)) {
            dir = guess;
            saveDir(dir);
        }
    }
    while (!dir) {
        var picked = Folder.selectDialog("Select the ai-reference-retriever folder (the one containing run.bat and app.py)");
        if (!picked) { return; } // user cancelled
        if (valid(picked.fsName)) {
            dir = picked.fsName;
            saveDir(dir);
        } else {
            alert("run.bat not found in:\n" + picked.fsName + "\n\nPick the folder that contains run.bat and app.py.");
        }
    }
    // windowless launcher (no console flash); falls back to run.bat
    var vbs = File(dir + "/start_hidden.vbs");
    if (vbs.exists) { vbs.execute(); return; }
    File(dir + "/run.bat").execute(); // launches the retriever
})();
