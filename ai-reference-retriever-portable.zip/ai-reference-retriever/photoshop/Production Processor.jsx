// Production Processor.jsx — open the AI Reference Retriever from inside Photoshop.
// Install: copy this file into  C:\Program Files\Adobe\Adobe Photoshop 2026\Presets\Scripts\
//          (restart Photoshop), then use File > Scripts > Production Processor.
// It launches the Production Processor window (Python/Tk); the tool passes images
// back via board\*.jpg drag-in or board\load_in_photoshop.jsx (File > Scripts > Browse).
#target photoshop

(function () {
    var toolDir = "C:\\Users\\nwentz\\ai-reference-retriever";
    var tool = new File(toolDir + "\\app.py");
    if (!tool.exists) {
        alert("Production Processor not found at:\n" + tool.fsName +
              "\n\nEdit the toolDir line at the top of Production Processor.jsx.");
        return;
    }
    // start detached so Photoshop never blocks waiting on the panel
    var cmd = 'cmd /c start "ProductionProcessor" /D "' + toolDir + '" pythonw.exe app.py';
    try {
        app.system(cmd);
    } catch (e) {
        alert("Could not launch the Production Processor:\n" + e +
              "\n\nIs Python installed with the PATH checkbox ticked?");
    }
})();
