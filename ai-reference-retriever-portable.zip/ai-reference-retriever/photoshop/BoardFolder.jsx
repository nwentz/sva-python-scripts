// BoardFolder.jsx — opens the retriever's board/ folder (drag images into Photoshop).
// Install: copy next to ProductionProcessor.jsx in
//   %APPDATA%\Adobe\Adobe Photoshop 2026\Presets\Scripts\
(function () {
    var home = Folder("~");
    var cfg = File(home.fsName + "/production_processor_dir.txt");
    if (!cfg.exists) {
        alert("Run File > Scripts > ProductionProcessor first (it remembers the folder).");
        return;
    }
    cfg.open("r");
    var dir = cfg.read();
    cfg.close();
    var board = Folder(dir + "/board");
    if (!board.exists) {
        alert("board/ folder not found:\n" + dir + "/board");
        return;
    }
    board.execute(); // opens in Explorer for drag-and-drop into Photoshop
})();
