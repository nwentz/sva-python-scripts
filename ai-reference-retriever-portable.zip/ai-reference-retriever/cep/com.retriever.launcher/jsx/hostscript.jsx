// hostscript.jsx — auto-loaded by the Retriever CEP panel (ES3 only).
// Remembers the ai-reference-retriever folder in ~/production_processor_dir.txt
function productionProcessorDir(pick) {
    var cfg = File(Folder("~").fsName + "/production_processor_dir.txt");
    if (cfg.exists) {
        cfg.open("r");
        var saved = cfg.read();
        cfg.close();
        if (saved && Folder(saved).exists && File(saved + "/run.bat").exists) { return saved; }
    }
    var guess = Folder("~").fsName + "/ai-reference-retriever";
    if (Folder(guess).exists && File(guess + "/run.bat").exists) {
        if (cfg.open("w")) { cfg.write(guess); cfg.close(); }
        return guess;
    }
    if (!pick) { return null; }
    var f = Folder.selectDialog("Locate your ai-reference-retriever folder");
    if (!f) { return null; }
    if (cfg.open("w")) { cfg.write(f.fsName); cfg.close(); }
    return f.fsName;
}
function productionProcessorLaunch() {
    var dir = productionProcessorDir(true);
    if (!dir) { return "cancelled — no folder chosen"; }
    var vbs = File(dir + "/start_hidden.vbs");
    if (vbs.exists) { vbs.execute(); return "retriever launching..."; }
    File(dir + "/run.bat").execute();
    return "retriever launching...";
}
function productionProcessorBoard() {
    var dir = productionProcessorDir(false);
    if (!dir) { return "open the Retriever once first"; }
    var board = Folder(dir + "/board");
    if (!board.exists) { return "board/ folder not found"; }
    board.execute();
    return "";
}
