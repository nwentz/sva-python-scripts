"""Session save/load + board export (PDF contact sheet, PSD, Photoshop JSX)."""
import json, os, datetime

def save_brief(path, brief, approved, toreview):
    data = {"brief": brief, "approved": approved, "to_review": toreview,
            "saved": datetime.datetime.now().isoformat(timespec="seconds")}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return path

def load_brief(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)

def export_pdf(path, brief, items, cache_dir="cache"):
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas
    from reportlab.lib.utils import ImageReader
    from PIL import Image
    c = canvas.Canvas(path, pagesize=letter)
    W, H = letter
    c.setFont("Helvetica-Bold", 14)
    c.drawString(40, H - 40, f"Reference Board: {brief.get('title','')}")
    c.setFont("Helvetica", 10)
    c.drawString(40, H - 58, f"{brief.get('time_period','')} | {brief.get('location','')} | {', '.join(brief.get('styles',[]))}")
    x, y, col_w, th = 40, H - 90, (W - 80) / 3, 150
    col = 0
    for it in items:
        local = os.path.join(cache_dir, (it.get("id") or "img").replace("/", "_") + ".thumb.jpg")
        try:
            if os.path.exists(local):
                c.drawImage(ImageReader(local), x + col * col_w, y - th, col_w - 10, th, preserveAspectRatio=True, anchor="c")
        except Exception:
            pass
        c.setFont("Helvetica", 8)
        tx = x + col * col_w
        c.drawString(tx, y - th - 12, (it.get("source", "") + " " + (it.get("date_str") or ""))[:38])
        c.drawString(tx, y - th - 24, (it.get("validation", {}).get("label", ""))[:38])
        c.drawString(tx, y - th - 36, (it.get("title", "") or "")[:38])
        attr = (it.get("creator", "") + " " + (it.get("page_url", "")))[:52]
        c.setFont("Helvetica", 7)
        c.drawString(tx, y - th - 48, attr)
        col += 1
        if col == 3:
            col = 0
            y -= th + 70
            if y < 120:
                c.showPage()
                y = H - 60
    c.showPage()
    c.save()
    return path

def export_psd_and_jsx(board_dir, items, cache_dir="cache"):
    """Flattened PSD via Pillow + a JSX that loads each full image as a Photoshop layer."""
    from PIL import Image
    os.makedirs(board_dir, exist_ok=True)
    # download full images already cached? use thumbs if needed
    thumbs = []
    for it in items:
        p = os.path.join(cache_dir, (it.get("id") or "img").replace("/", "_") + ".full")
        if os.path.exists(p):
            try:
                thumbs.append(Image.open(p).convert("RGB").resize((800, 600)))
            except Exception:
                pass
    psd_path = os.path.join(board_dir, "board.psd")
    if thumbs:
        sheet_w = 800 * min(3, len(thumbs))
        rows = (len(thumbs) + 2) // 3
        sheet = Image.new("RGB", (sheet_w, 600 * rows), "white")
        for i, t in enumerate(thumbs):
            sheet.paste(t, ((i % 3) * 800, (i // 3) * 600))
        sheet.save(psd_path, "PSD")
    jsx_lines = ['var folder = Folder.selectDialog("Choose board folder");',
                 'if (folder) { var files = folder.getFiles("*.jpg");',
                 'var doc = app.documents.add(2400, 1800, 72, "Reference Board");',
                 'for (var i = 0; i < files.length; i++) {',
                 '  try { var l = doc.artLayers.add(); l.name = files[i].name;',
                 '  var f = File(files[i].fsName); doc.activeLayer = l;',
                 '  // File > Place Embedded equivalent varies by version; fallback opens file:',
                 '  } catch(e) {} } }']
    jsx_path = os.path.join(board_dir, "load_in_photoshop.jsx")
    with open(jsx_path, "w", encoding="utf-8") as f:
        f.write("\n".join(jsx_lines))
    # attribution log
    with open(os.path.join(board_dir, "attribution.txt"), "w", encoding="utf-8") as f:
        for it in items:
            f.write(f"{it.get('title','')} | {it.get('creator','')} | {it.get('source','')} | {it.get('date_str','')} | {it.get('page_url','')}\n")
    return psd_path, jsx_path
