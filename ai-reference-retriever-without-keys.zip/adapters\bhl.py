"""Biodiversity Heritage Library adapter - public domain natural-history illustrations.
API key (free, email signup): https://www.biodiversitylibrary.org/api3
Docs: https://www.biodiversitylibrary.org/api3/docs
"""
import html as _html
import re
import time

from validator import clean_query

from .http import get

API = "https://www.biodiversitylibrary.org/api3"
KEY = "e23acfcf-d293-4c0d-9276-7a4345db84a7"
UA = {"User-Agent": "AI-Reference-Retriever/1.0 (student midterm; contact: local)"}

def _text(raw):
    return _html.unescape(re.sub(r"<[^>]+>", " ", raw or "")).strip(" :;,-")

def _fetch_title_pages(title_id):
    """Return list of page dicts for a title."""
    try:
        r = get(API, params={"op": "TitleGetMetadata", "titleid": title_id,
                             "apikey": KEY, "format": "json"}, headers=UA, timeout=25)
        r.raise_for_status()
        data = r.json()
        # BHL wraps result under "Result"
        res = data.get("Result") if isinstance(data, dict) else data
        if isinstance(res, list):
            res = res[0] if res else {}
        pages = []
        for item in (res.get("Items") or []):
            for p in (item.get("Pages") or []):
                pages.append(p)
        return pages
    except Exception:
        return []

def search(query, limit=6, brief=None):
    base = clean_query(query) or query
    last = None
    try:
        r = get(API, params={"op": "TitleSearch", "searchterm": base,
                             "apikey": KEY, "format": "json"}, headers=UA, timeout=25)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        return [], f"BHL: {e} (retry on home network)"
    res = data.get("Result") if isinstance(data, dict) else data
    if not isinstance(res, list):
        res = []
    items = []
    for t in res[:max(1, limit)]:
        title_id = t.get("TitleID") or t.get("titleID")
        title = _text(t.get("Title") or t.get("ShortTitle") or "(untitled)")
        pages = _fetch_title_pages(title_id) if title_id else []
        for p in pages[:2]:
            pid = p.get("PageID") or p.get("pageID")
            if not pid:
                continue
            items.append({
                "id": "bhl-" + str(pid),
                "title": title,
                "date_str": str(t.get("PublicationDate") or t.get("Date") or ""),
                "creator": _text(t.get("Author") or ""),
                "source": "BHL",
                "image_url": f"https://www.biodiversitylibrary.org/pageimage/{pid}",
                "thumb_url": f"https://www.biodiversitylibrary.org/pagethumb/{pid}",
                "large_url": f"https://www.biodiversitylibrary.org/pageimage/{pid}",
                "page_url": f"https://www.biodiversitylibrary.org/page/{pid}",
                "medium": "illustration",
                "extra": "public domain",
            })
            if len(items) >= limit:
                break
        if len(items) >= limit:
            break
    if not items:
        return [], f"BHL: 0 PD hits for '{base}' (try broader terms)"
    return items[:limit], None
