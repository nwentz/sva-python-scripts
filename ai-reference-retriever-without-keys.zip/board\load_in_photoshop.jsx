var folder = Folder.selectDialog("Choose board folder");
if (folder) { var files = folder.getFiles("*.jpg");
var doc = app.documents.add(2400, 1800, 72, "Reference Board");
for (var i = 0; i < files.length; i++) {
  try { var l = doc.artLayers.add(); l.name = files[i].name;
  var f = File(files[i].fsName); doc.activeLayer = l;
  // File > Place Embedded equivalent varies by version; fallback opens file:
  } catch(e) {} } }